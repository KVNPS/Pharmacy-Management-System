

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Inventory.ConnectionFactory;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Connection con = null;
		// ResultSet rs = null;
		 con=ConnectionFactory.getConnection(); 
		 response.setContentType("text/html");
			String s1=request.getParameter("username");
			String s2=request.getParameter("password");
			String s3=request.getParameter("name");
			String s4=request.getParameter("email");
			String s5=request.getParameter("phone_no");
			 PrintWriter out=response.getWriter();  
	
			try {			
				PreparedStatement pst=con.prepareStatement("insert into register values(?,?,?,?,?)");
				pst.setString(1,s1);  
				pst.setString(2,s2);  
				pst.setString(3,s3);  
				pst.setString(4,s4); 
				pst.setString(5,s5);
				pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/*if(s5.length()>10 && s5.length()<10)
			{
				out.print("<script>alert(Number should be 10 digits you idiot)</script>");
			}*/
			 request.getRequestDispatcher("login.jsp").forward(request, response);	
	}
	}


