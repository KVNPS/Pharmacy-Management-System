

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Inventory.ConnectionFactory;

@WebServlet("/RemoveMedicine")
public class RemoveMedicine extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			Connection con = null;
			// ResultSet rs = null;
			 con=ConnectionFactory.getConnection(); 
			 String s1=request.getParameter("med_id");
			 PreparedStatement pst=con.prepareStatement("delete from medicine where med_id=? ");
				pst.setString(1, s1);
				pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("Index.jsp").forward(request, response);
			
	}
	
	

}
