

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Inventory.ConnectionFactory;


@WebServlet("/updatepassword")
public class updatepassword extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 Connection con = null;
			// ResultSet rs = null;
			 con=ConnectionFactory.getConnection(); 
			 response.setContentType("text/html");
				String uname=request.getParameter("username");
				String pwd=request.getParameter("password");
				
						
					try {
						PreparedStatement pst=con.prepareStatement("update login SET password=? where  username=?");
						pst.setString(1,pwd); 
						pst.setString(2,uname); 
						
						
						pst.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					
					request.getRequestDispatcher("login.jsp").forward(request, response);
	}

}
