
import Inventory.ConnectionFactory;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession session = request.getSession(false); //Fetch session object
		 
		 if(session!=null) //If session is not null
		 {
		 session.invalidate(); //removes all session attributes bound to the session
		 request.setAttribute("errMessage", "You have logged out successfully");
		 RequestDispatcher requestDispatcher = request.getRequestDispatcher("login.jsp");
		 requestDispatcher.forward(request, response);
		 
		 }
		 }
		}
	