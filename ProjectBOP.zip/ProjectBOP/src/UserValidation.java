import java.sql.*;

import javax.servlet.annotation.WebServlet;

import Inventory.ConnectionFactory;
import Inventory.LoginInfo;
@WebServlet("/UserValidation")
public class UserValidation {

	public String authenticateUser(LoginInfo loginBean)
	{
	 String userName = loginBean.getUserName();
	 String password = loginBean.getPassword();
	 
	 Connection con = null;
	 Statement statement = null;
	 ResultSet resultSet = null;
	 
	 String userNameDB = "";
	 String passwordDB = "";
	 String roleDB = "";
	 
	
 con=ConnectionFactory.getConnection(); 
	 
		try {
			statement = con.createStatement();
			 resultSet = statement.executeQuery("select username,password,role from login");
			 
			 while(resultSet.next())
			 {
			 userNameDB = resultSet.getString("username");
			 passwordDB = resultSet.getString("password");
			 roleDB = resultSet.getString("role");
			 
			 if(userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("admin"))
			 return "Admin_Role";
			
			
			 else if (userName.equals(userNameDB) && password.equals(passwordDB) && roleDB.equals("user"))
			 return "User_Role";
			 }
			 
			
			 return "Invalid user credentials";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	
	}
	}

