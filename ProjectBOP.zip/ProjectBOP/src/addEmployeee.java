

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Inventory.ConnectionFactory;

/**
 * Servlet implementation class addEmployeee
 */
@WebServlet("/addEmployeee")
public class addEmployeee extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 Connection con = null;
		// ResultSet rs = null;
		 con=ConnectionFactory.getConnection(); 
		 response.setContentType("text/html");
			String s1=request.getParameter("uname");
			String s2=request.getParameter("pwd");
					
				try {
					PreparedStatement pst=con.prepareStatement("insert into login values(?,?,?)");
					pst.setString(1,s1);  
					pst.setString(2,s2);  
					pst.setString(3,"user");  
					pst.executeUpdate();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				 request.getRequestDispatcher("Admin.jsp").forward(request, response);
	}

	
	
}
