

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Inventory.ConnectionFactory;


@WebServlet("/addMedicine")
public class addMedicine extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 Connection con = null;
		// ResultSet rs = null;
		 con=ConnectionFactory.getConnection(); 
		 response.setContentType("text/html");
			String s1=request.getParameter("med_id");
			String s2=request.getParameter("title");
			String s3=request.getParameter("qty");
			String s4=request.getParameter("unit_price");
			
			try {
				PreparedStatement pst=con.prepareStatement("insert into medicine values(?,?,?,?)");
				pst.setString(1,s1);  
				pst.setString(2,s2);  
				pst.setString(3,s3);  
				pst.setString(4,s4); 
				pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 request.getRequestDispatcher("Index.jsp").forward(request, response);
	}

}
