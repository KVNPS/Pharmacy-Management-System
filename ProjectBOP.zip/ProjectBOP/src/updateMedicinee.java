

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Inventory.ConnectionFactory;


@WebServlet("/updateMedicinee")
public class updateMedicinee extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 Connection con = null;
			// ResultSet rs = null;
			 con=ConnectionFactory.getConnection(); 
			 response.setContentType("text/html");
				String s1=request.getParameter("med_id");
				String s2=request.getParameter("qty");
				String s3=request.getParameter("unit_price");
				int a=Integer.parseInt(s1);
				int b=Integer.parseInt(s2);
				int c=Integer.parseInt(s3);
						
					try {
						PreparedStatement pst=con.prepareStatement("update medicine SET qty=?,unit_price=? where  med_id=?");
						pst.setInt(1,b); 
						pst.setInt(2,c);
						pst.setInt(3,a);  
						
						pst.executeUpdate();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					
					request.getRequestDispatcher("Index.jsp").forward(request, response);
		}

		
		
		
	}


